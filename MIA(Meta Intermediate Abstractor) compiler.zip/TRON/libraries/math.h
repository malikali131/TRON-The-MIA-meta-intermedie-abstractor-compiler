#ifndef MIA_MATH_H
#define MIA_MATH_H

#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

double taqat(double base,double exp){return pow(base,exp);}
double jazar(double x){return sqrt(x);}
double mutlaq(double x){return fabs(x);}
double gol_karo(double x){return round(x);}
double upar_karo(double x){return ceil(x);}
double neeche_karo(double x){return floor(x);}
double baqi_float(double a,double b){return fmod(a,b);}
double farak(double a, double b){return fdim(a, b);}
double sin_zavia(double x){return sin(x);}
double cos_zavia(double x){return cos(x);}
double tan_zavia(double x){return tan(x);}
double log_e(double x){return log(x);}
double log_10(double x){return log10(x);}
double exp_e(double x){return exp(x);}
double max_num(double a,double b){return fmax(a,b);}
double min_num(double a,double b){return fmin(a,b);}

#endif