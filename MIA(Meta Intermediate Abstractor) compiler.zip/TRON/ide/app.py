"""
app.py  —  Mia Language IDE v2.0
Location: project/ide/app.py
"""

import tkinter as tk
from tkinter import scrolledtext, ttk, simpledialog, filedialog
import subprocess
import os
import json

# ── Path constants ────────────────────────────────────────────────────────────
IDE_DIR       = os.path.dirname(os.path.abspath(__file__))
PROJECT       = os.path.dirname(IDE_DIR)
SYSTEM_DIR    = os.path.join(PROJECT, "system")
INPUTS_DIR    = os.path.join(PROJECT, "inputs")
DOWNLOADS_DIR = os.path.join(PROJECT, "downloads")
TEMP_DIR      = os.path.join(SYSTEM_DIR, "temp")
MIA_FILE      = os.path.join(INPUTS_DIR, "hello.mia")
TAC_FILE      = os.path.join(TEMP_DIR,   "mia_tac.tac")
SYM_FILE      = os.path.join(TEMP_DIR,   "mia_symtable.json")

os.makedirs(INPUTS_DIR,    exist_ok=True)
os.makedirs(DOWNLOADS_DIR, exist_ok=True)
os.makedirs(TEMP_DIR,      exist_ok=True)

# ── Colours ───────────────────────────────────────────────────────────────────
BG_DARK   = "#1E1E1E"
BG_PANEL  = "#252526"
BG_BLACK  = "#000000"
FG_WHITE  = "#D4D4D4"
FG_GREEN  = "#4EC94E"
FG_YELLOW = "#DCDCAA"
FG_RED    = "#F44747"
FG_CYAN   = "#4FC1FF"
ACCENT    = "#4CAF50"

context_menu = None

# ── Widget helpers ────────────────────────────────────────────────────────────
def _write(widget, text, fg=None):
    widget.config(state=tk.NORMAL)
    if fg:
        tag = f"color_{fg.replace('#','')}"
        widget.tag_configure(tag, foreground=fg)
        widget.insert(tk.END, text, tag)
    else:
        widget.insert(tk.END, text)
    widget.config(state=tk.DISABLED)
    widget.see(tk.END)

def _clear(widget):
    widget.config(state=tk.NORMAL)
    widget.delete("1.0", tk.END)
    widget.config(state=tk.DISABLED)

# ── Copy helpers ──────────────────────────────────────────────────────────────
def copy_terminal_content():
    try:
        content = output_terminal.get("1.0", tk.END).strip()
        if content:
            window.clipboard_clear()
            window.clipboard_append(content)
            window.update()
    except Exception:
        pass

def show_context_menu(event):
    try:
        if context_menu:
            context_menu.tk_popup(event.x_root, event.y_root)
    finally:
        if context_menu:
            context_menu.grab_release()

# ── Save / Load ───────────────────────────────────────────────────────────────
def save_file():
    filename = simpledialog.askstring("Save File", "Enter filename (without .mia):", parent=window)
    if not filename or not filename.strip():
        return
    save_path = os.path.join(DOWNLOADS_DIR, filename.strip() + ".mia")
    try:
        with open(save_path, "w", encoding="utf-8") as fh:
            fh.write(editor.get("1.0", tk.END))
        _write(output_terminal, f"Saved: downloads/{filename.strip()}.mia\n", FG_YELLOW)
    except Exception as e:
        _write(output_terminal, f"Save failed: {e}\n", FG_RED)

def load_file():
    path = filedialog.askopenfilename(
        initialdir=DOWNLOADS_DIR,
        title="Open .mia file",
        filetypes=[("Mia files", "*.mia"), ("All files", "*.*")]
    )
    if path:
        with open(path, "r", encoding="utf-8") as fh:
            content = fh.read()
        editor.delete("1.0", tk.END)
        editor.insert(tk.END, content)

# ── Symbol Table ──────────────────────────────────────────────────────────────
def render_symtable(frame):
    for child in frame.winfo_children():
        child.destroy()

    tk.Label(frame, text=" Symbol Table ", bg=BG_PANEL, fg=FG_CYAN,
             font=("Consolas", 10, "bold"), anchor="w").pack(fill=tk.X)

    if not os.path.exists(SYM_FILE):
        tk.Label(frame, text="(no data yet — run a program first)",
                 bg=BG_PANEL, fg=FG_WHITE,
                 font=("Consolas", 10)).pack(padx=8, pady=8, anchor="w")
        return

    try:
        with open(SYM_FILE, "r") as f:
            entries = json.load(f)
    except Exception as e:
        tk.Label(frame, text=f"Error: {e}", bg=BG_PANEL, fg=FG_RED,
                 font=("Consolas", 10)).pack(padx=8, pady=4, anchor="w")
        return

    if not entries:
        tk.Label(frame, text="(empty symbol table)", bg=BG_PANEL, fg=FG_WHITE,
                 font=("Consolas", 10)).pack(padx=8, pady=8, anchor="w")
        return

    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Sym.Treeview", background=BG_DARK, foreground=FG_WHITE,
                    fieldbackground=BG_DARK, rowheight=22, font=("Consolas", 10))
    style.configure("Sym.Treeview.Heading", background=BG_PANEL, foreground=FG_CYAN,
                    font=("Consolas", 10, "bold"))
    style.map("Sym.Treeview",
              background=[("selected", "#094771")],
              foreground=[("selected", FG_WHITE)])

    cols = ("Name", "Type", "Line")
    tv = ttk.Treeview(frame, columns=cols, show="headings",
                      style="Sym.Treeview", selectmode="browse")
    tv.heading("Name", text="Name")
    tv.heading("Type", text="Type")
    tv.heading("Line", text="Decl. Line")
    tv.column("Name", width=100, anchor="w")
    tv.column("Type", width=80,  anchor="center")
    tv.column("Line", width=80,  anchor="center")
    tv.tag_configure("odd",  background="#252526")
    tv.tag_configure("even", background="#2D2D2D")

    for i, entry in enumerate(entries):
        tv.insert("", tk.END,
                  values=(entry.get("name","?"), entry.get("type","?"), entry.get("line","?")),
                  tags=("odd" if i % 2 == 0 else "even",))

    sb = ttk.Scrollbar(frame, orient="vertical", command=tv.yview)
    tv.configure(yscrollcommand=sb.set)
    tv.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    sb.pack(side=tk.RIGHT, fill=tk.Y)

# ── Run ───────────────────────────────────────────────────────────────────────
def run_code():
    with open(MIA_FILE, "w", encoding="utf-8") as fh:
        fh.write(editor.get("1.0", tk.END))

    _clear(output_terminal)
    _clear(tac_terminal)
    window.update()

    try:
        proc = subprocess.run(
            ["mingw32-make", "run"],
            cwd=SYSTEM_DIR, capture_output=True, text=True, shell=True
        )
    except FileNotFoundError:
        _write(output_terminal, "ERROR: mingw32-make not found.\n", FG_RED)
        render_symtable(sym_frame)
        return

    stdout = proc.stdout
    stderr = proc.stderr
    build_failed = (proc.returncode != 0) or ("error:" in stderr.lower())

    if build_failed:
        _write(output_terminal, "=== Build / Transpiler Errors ===\n", FG_RED)
        if stderr.strip(): _write(output_terminal, stderr.strip() + "\n", FG_RED)
        if stdout.strip(): _write(output_terminal, stdout.strip() + "\n", FG_RED)
    else:
        clean_lines = [
            ln for ln in stdout.splitlines()
            if not ln.startswith("[1/3]")
            and not ln.startswith("[2/3]")
            and not ln.startswith("[3/3]")
            and not ln.startswith("---")
            and not ln.startswith("cd ")
            and not ln.startswith("gcc ")
            and not ln.startswith("output/")
            and not ln.startswith("mingw32")
            and not ln.strip() == ""
        ]
        program_output = "\n".join(clean_lines).strip()
        if program_output:
            _write(output_terminal, program_output + "\n", FG_GREEN)
        else:
            _write(output_terminal, "(program produced no output)\n", FG_YELLOW)

        if stderr.strip():
            _write(output_terminal, "\n--- Warnings ---\n", FG_YELLOW)
            _write(output_terminal, stderr.strip() + "\n", FG_YELLOW)

    _clear(tac_terminal)
    if os.path.exists(TAC_FILE):
        try:
            with open(TAC_FILE, "r", encoding="utf-8") as fh:
                _write(tac_terminal, fh.read(), FG_CYAN)
        except Exception as e:
            _write(tac_terminal, f"Could not read TAC file:\n{e}\n", FG_RED)
    else:
        _write(tac_terminal, "(TAC not generated)\n", FG_YELLOW)

    render_symtable(sym_frame)
    subprocess.run(["mingw32-make", "clean_temp"], cwd=SYSTEM_DIR, capture_output=True, shell=True)

# ── Window ────────────────────────────────────────────────────────────────────
window = tk.Tk()
window.title("Mia Language IDE  v2.0")
window.geometry("1300x800")
window.configure(bg=BG_DARK)
window.minsize(900, 600)

# ── Top bar ───────────────────────────────────────────────────────────────────
top_bar = tk.Frame(window, bg="#333333", pady=6)
top_bar.pack(fill=tk.X)

tk.Label(top_bar, text="Mia IDE", bg="#333333", fg=FG_CYAN,
         font=("Segoe UI", 13, "bold")).pack(side=tk.LEFT, padx=14)

tk.Button(top_bar, text="▶  Run", font=("Segoe UI", 11, "bold"),
          bg=ACCENT, fg="white", activebackground="#45a049",
          padx=18, pady=2, cursor="hand2", relief=tk.FLAT,
          command=run_code).pack(side=tk.LEFT, padx=8)

tk.Button(top_bar, text="💾  Save", font=("Segoe UI", 11, "bold"),
          bg="#2196F3", fg="white", activebackground="#1976D2",
          padx=18, pady=2, cursor="hand2", relief=tk.FLAT,
          command=save_file).pack(side=tk.LEFT, padx=4)

tk.Button(top_bar, text="📂  Open", font=("Segoe UI", 11, "bold"),
          bg="#555555", fg="white", activebackground="#444444",
          padx=18, pady=2, cursor="hand2", relief=tk.FLAT,
          command=load_file).pack(side=tk.LEFT, padx=4)

# ── Editor ────────────────────────────────────────────────────────────────────
editor_frame = tk.Frame(window, bg=BG_DARK)
editor_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=(4, 0))

tk.Label(editor_frame, text=" Code Editor ", bg=BG_DARK, fg=FG_WHITE,
         font=("Consolas", 9)).pack(anchor="w")

editor = scrolledtext.ScrolledText(
    editor_frame, wrap=tk.NONE, font=("Consolas", 13),
    bg=BG_DARK, fg=FG_WHITE, insertbackground="white",
    selectbackground="#094771", undo=True, tabs="4"
)
editor.pack(fill=tk.BOTH, expand=True)
editor.insert(tk.END,
    'shamil "math.h";\n\n'
    '// Roman Urdu code likhein\n'
    'rakho x = 10;\n'
    'rakho y = 20;\n'
    'rakho sum = x + y;\n\n'
    'bol "Addition Result: ", sum;\n'
    'bol "Hello from Mia!";\n')

# ── Bottom panels ─────────────────────────────────────────────────────────────
bottom = tk.PanedWindow(window, orient=tk.HORIZONTAL,
                        bg="#555555", sashwidth=4, sashrelief=tk.FLAT)
bottom.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

# Output
out_frame = tk.Frame(bottom, bg=BG_BLACK)
out_header = tk.Frame(out_frame, bg=BG_BLACK)
out_header.pack(fill=tk.X, anchor="w", padx=4, pady=2)
tk.Label(out_header, text=" Output Terminal ", bg=BG_BLACK, fg=FG_GREEN,
         font=("Consolas", 9, "bold")).pack(side=tk.LEFT)
tk.Button(out_header, text="📋 Copy", font=("Consolas", 8, "bold"),
          bg="#333333", fg=FG_WHITE, relief=tk.FLAT, bd=0,
          cursor="hand2", padx=6, command=copy_terminal_content).pack(side=tk.RIGHT, padx=5)
output_terminal = scrolledtext.ScrolledText(
    out_frame, bg=BG_BLACK, fg=FG_GREEN, font=("Consolas", 11),
    state=tk.DISABLED, wrap=tk.WORD, insertbackground=FG_GREEN)
output_terminal.pack(fill=tk.BOTH, expand=True)
bottom.add(out_frame, minsize=280)

context_menu = tk.Menu(window, tearoff=0, bg=BG_PANEL, fg=FG_WHITE, activebackground="#094771")
context_menu.add_command(label="Copy All Output", command=copy_terminal_content)
output_terminal.bind("<Button-3>", show_context_menu)

# TAC
tac_frame = tk.Frame(bottom, bg=BG_PANEL)
tk.Label(tac_frame, text=" Three-Address Code (TAC) ", bg=BG_PANEL, fg=FG_CYAN,
         font=("Consolas", 9, "bold")).pack(anchor="w", padx=4)
tac_terminal = scrolledtext.ScrolledText(
    tac_frame, bg=BG_PANEL, fg=FG_CYAN, font=("Consolas", 10),
    state=tk.DISABLED, wrap=tk.NONE, insertbackground=FG_CYAN)
tac_terminal.pack(fill=tk.BOTH, expand=True)
bottom.add(tac_frame, minsize=280)

# Symbol Table
sym_frame = tk.Frame(bottom, bg=BG_PANEL)
bottom.add(sym_frame, minsize=260)
render_symtable(sym_frame)

window.mainloop()