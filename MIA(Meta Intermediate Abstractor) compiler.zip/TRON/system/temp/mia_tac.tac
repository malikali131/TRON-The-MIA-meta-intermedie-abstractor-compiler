; ===== Mia Three-Address Code =====
; Generated from source file
; Format: result = operand1 op operand2
;
BEGIN_MAIN
; INCLUDE math.h
x = 10
y = 20
t0 = x + y
sum = t0
PRINT "Addition Result: "
PRINT sum
PRINT "Hello from Mia!"
END_MAIN
