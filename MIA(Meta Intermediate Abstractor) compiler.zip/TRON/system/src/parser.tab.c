
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Copy the first part of user declarations.  */

/* Line 189 of yacc.c  */
#line 1 "parser.y"

/* =============================================================================
 * parser.y  —  Bison Parser + TAC Generator for the Mia Transpiler
 * Location : project/system/src/parser.y
 *
 * Outputs (all written to CWD = temp/):
 *   generated_target.c  — valid C code compiled by GCC
 *   mia_tac.tac         — three-address code listing read by the IDE
 *   mia_symtable.json   — symbol table dump read by the IDE
 *
 * Three-Address Code format:
 *   t0 = 10                   (copy / literal)
 *   t1 = x + y                (binary op)
 *   t2 = jazar(x)             (function call result)
 *   IF cond GOTO L1           (conditional jump)
 *   GOTO L2                   (unconditional jump)
 *   LABEL L1                  (label)
 *   PARAM x                   (function argument)
 *   CALL func, n              (call with n args)
 *   RETURN val                (return value)
 * ============================================================================= */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symtable.h"

extern int yylineno;
int  yylex();
void yyerror(const char *s);

/* ── C code output streams ──────────────────────────────────────────────────*/
FILE *f_func;        /* function definitions  */
FILE *f_main;        /* main() body           */
FILE *f_includes;    /* #include directives   */
FILE *f_tac;         /* TAC output            */
FILE *current_out;   /* pointer to active stream (f_main or f_func) */

/* ── TAC helpers ─────────────────────────────────────────────────────────── */
static int tac_tmp   = 0;   /* __t0, __t1, ...  */
static int tac_label = 0;   /* L0, L1, ...      */

static char *new_tac_tmp(void) {
    char *buf = malloc(16);
    snprintf(buf, 16, "t%d", tac_tmp++);
    return buf;
}
static char *new_label(void) {
    char *buf = malloc(16);
    snprintf(buf, 16, "L%d", tac_label++);
    return buf;
}
#define TAC(...) fprintf(f_tac, __VA_ARGS__)

/* ── C expression helpers ───────────────────────────────────────────────────*/
static char *make_expr(const char *a, const char *op, const char *b) {
    char *buf = malloc(strlen(a) + strlen(op) + strlen(b) + 4);
    sprintf(buf, "%s %s %s", a, op, b);
    return buf;
}
static char *wrap_func(const char *func, const char *arg) {
    char *buf = malloc(strlen(func) + strlen(arg) + 4);
    sprintf(buf, "%s(%s)", func, arg);
    return buf;
}


/* Line 189 of yacc.c  */
#line 141 "parser.tab.c"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ID = 258,
     NUM = 259,
     STRING_LIT = 260,
     SHAMIL = 261,
     RAKHO = 262,
     BOL = 263,
     AGAR = 264,
     WARNA = 265,
     JAB_TAK = 266,
     HAR = 267,
     AUR = 268,
     YA = 269,
     TO_STR = 270,
     TO_NUM = 271,
     KAAM = 272,
     WAPAS = 273,
     EQ = 274,
     NEQ = 275,
     LEQ = 276,
     GEQ = 277
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 214 of yacc.c  */
#line 69 "parser.y"

    char *str;
    struct { char *code; char *tac; int type; } expr_info;



/* Line 214 of yacc.c  */
#line 206 "parser.tab.c"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */


/* Line 264 of yacc.c  */
#line 218 "parser.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   235

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  38
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  17
/* YYNRULES -- Number of rules.  */
#define YYNRULES  50
/* YYNRULES -- Number of states.  */
#define YYNSTATES  129

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   277

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      33,    34,    27,    25,    37,    26,     2,    28,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,    29,
      23,    30,    24,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    31,     2,    32,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    35,     2,    36,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint8 yyprhs[] =
{
       0,     0,     3,     4,     7,    10,    11,    15,    21,    28,
      36,    40,    41,    51,    52,    61,    62,    81,    82,    83,
      94,    98,   104,   106,   110,   111,   117,   118,   120,   124,
     125,   127,   131,   132,   134,   136,   138,   140,   145,   150,
     154,   158,   162,   166,   170,   174,   178,   182,   186,   190,
     194
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int8 yyrhs[] =
{
      39,     0,    -1,    -1,    40,    41,    -1,    42,    41,    -1,
      -1,     6,     5,    29,    -1,     7,     3,    30,    54,    29,
      -1,     7,     3,    31,     4,    32,    29,    -1,     3,    31,
      54,    32,    30,    54,    29,    -1,     8,    48,    29,    -1,
      -1,     9,    33,    53,    34,    35,    43,    41,    36,    49,
      -1,    -1,    11,    33,    53,    34,    35,    44,    41,    36,
      -1,    -1,    12,    33,     7,     3,    30,    54,    37,    53,
      37,     7,     3,    30,    54,    34,    35,    45,    41,    36,
      -1,    -1,    -1,    17,     3,    33,    46,    51,    34,    35,
      47,    41,    36,    -1,    18,    54,    29,    -1,     3,    33,
      52,    34,    29,    -1,    54,    -1,    48,    37,    54,    -1,
      -1,    10,    35,    50,    41,    36,    -1,    -1,     3,    -1,
      51,    37,     3,    -1,    -1,    54,    -1,    52,    37,    54,
      -1,    -1,    54,    -1,     4,    -1,     5,    -1,     3,    -1,
       3,    31,    54,    32,    -1,     3,    33,    52,    34,    -1,
      54,    25,    54,    -1,    54,    26,    54,    -1,    54,    27,
      54,    -1,    54,    28,    54,    -1,    54,    19,    54,    -1,
      54,    20,    54,    -1,    54,    23,    54,    -1,    54,    24,
      54,    -1,    54,    21,    54,    -1,    54,    22,    54,    -1,
      54,    13,    54,    -1,    54,    14,    54,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,    91,    91,    91,   153,   153,   158,   166,   182,   189,
     196,   203,   202,   218,   217,   231,   230,   248,   254,   247,
     263,   270,   279,   288,   302,   301,   306,   311,   317,   323,
     328,   333,   340,   344,   348,   353,   358,   365,   377,   389,
     406,   411,   416,   421,   426,   431,   436,   441,   446,   451,
     456
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ID", "NUM", "STRING_LIT", "SHAMIL",
  "RAKHO", "BOL", "AGAR", "WARNA", "JAB_TAK", "HAR", "AUR", "YA", "TO_STR",
  "TO_NUM", "KAAM", "WAPAS", "EQ", "NEQ", "LEQ", "GEQ", "'<'", "'>'",
  "'+'", "'-'", "'*'", "'/'", "';'", "'='", "'['", "']'", "'('", "')'",
  "'{'", "'}'", "','", "$accept", "program", "$@1", "stmts", "stmt", "$@2",
  "$@3", "$@4", "$@5", "$@6", "bol_list", "warna_opt", "$@7", "param_list",
  "arg_list", "cond", "expr", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,    60,    62,    43,    45,    42,    47,    59,
      61,    91,    93,    40,    41,   123,   125,    44
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    38,    40,    39,    41,    41,    42,    42,    42,    42,
      42,    43,    42,    44,    42,    45,    42,    46,    47,    42,
      42,    42,    48,    48,    50,    49,    49,    51,    51,    51,
      52,    52,    52,    53,    54,    54,    54,    54,    54,    54,
      54,    54,    54,    54,    54,    54,    54,    54,    54,    54,
      54
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     2,     2,     0,     3,     5,     6,     7,
       3,     0,     9,     0,     8,     0,    18,     0,     0,    10,
       3,     5,     1,     3,     0,     5,     0,     1,     3,     0,
       1,     3,     0,     1,     1,     1,     1,     4,     4,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       2,     0,     5,     1,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     3,     5,     0,    32,     0,     0,    36,
      34,    35,     0,    22,     0,     0,     0,     0,     0,     4,
       0,     0,    30,     6,     0,     0,     0,    32,    10,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    33,     0,     0,    17,    20,     0,     0,
       0,     0,     0,     0,     0,    23,    49,    50,    43,    44,
      47,    48,    45,    46,    39,    40,    41,    42,     0,     0,
       0,    29,     0,    21,    31,     7,     0,    37,    38,    11,
      13,     0,    27,     0,     0,     8,     5,     5,     0,     0,
       0,     9,     0,     0,     0,    18,    28,    26,    14,     0,
       5,     0,    12,     0,     0,    24,     0,    19,     5,     0,
       0,     0,    25,     0,     0,    15,     5,     0,    16
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int8 yydefgoto[] =
{
      -1,     1,     2,    13,    14,    96,    97,   126,    81,   110,
      22,   112,   118,    93,    31,    52,    53
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -26
static const yytype_int16 yypact[] =
{
     -26,     2,   206,   -26,    -5,    46,    49,    10,    44,    45,
      50,    66,    10,   -26,   206,    10,    10,    69,    15,    43,
     -26,   -26,   -25,   164,    10,    10,    72,    64,   113,   -26,
      68,    13,   164,   -26,    10,    98,    10,    10,   -26,    10,
      10,    10,    10,    10,    10,    10,    10,    10,    10,    10,
      10,    10,    67,   164,    70,   100,   -26,   -26,    75,    77,
      10,   130,    76,    97,    34,   164,   207,   180,    39,    39,
      39,    39,    39,    39,   -21,   -21,   -26,   -26,    74,    78,
      82,   125,    10,   -26,   164,   -26,   101,   -26,   -26,   -26,
     -26,    10,   -26,    36,   147,   -26,   206,   206,    35,    96,
     142,   -26,   110,   111,    10,   -26,   -26,   138,   -26,   126,
     206,   127,   -26,   157,   129,   -26,   176,   -26,   206,   150,
     145,    10,   -26,    -3,   159,   -26,   206,   146,   -26
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -26,   -26,   -26,   -11,   -26,   -26,   -26,   -26,   -26,   -26,
     -26,   -26,   -26,   -26,   158,   -24,    -7
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const yytype_uint8 yytable[] =
{
      23,    54,     3,    29,    38,    28,    50,    51,    30,    32,
      40,    41,    39,    19,    20,    21,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    15,    61,    16,    63,
      32,   124,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    34,    35,    59,    40,    41,
      60,    17,    18,    84,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    48,    49,    50,    51,    88,    27,
      99,    60,   104,   100,    36,    94,    37,    24,    25,    55,
     109,    40,    41,    26,    98,   102,   103,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    56,    33,   114,
      58,    78,    62,    80,    79,    82,    83,   120,    86,    89,
      40,    41,    91,    90,   123,   127,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    40,    41,    92,    87,
      95,   105,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    57,    40,    41,   106,   107,   108,   111,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    85,
      40,    41,   115,   113,   116,   117,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,   101,    40,    41,   119,
     121,   122,   128,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    40,   125,    64,     0,     0,     0,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,     4,
       0,     0,     5,     6,     7,     8,     0,     9,    10,     0,
       0,     0,     0,    11,    12,     0,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51
};

static const yytype_int8 yycheck[] =
{
       7,    25,     0,    14,    29,    12,    27,    28,    15,    16,
      13,    14,    37,     3,     4,     5,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    31,    34,    33,    36,
      37,    34,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    30,    31,    34,    13,    14,
      37,     5,     3,    60,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    25,    26,    27,    28,    34,     3,
      34,    37,    37,    37,    31,    82,    33,    33,    33,     7,
     104,    13,    14,    33,    91,    96,    97,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    33,    29,   110,
      32,    34,     4,     3,    34,    30,    29,   118,    32,    35,
      13,    14,    30,    35,   121,   126,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    13,    14,     3,    32,
      29,    35,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    13,    14,     3,    36,    36,    10,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      13,    14,    35,    37,     7,    36,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    13,    14,     3,
      30,    36,    36,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    13,    35,    37,    -1,    -1,    -1,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,     3,
      -1,    -1,     6,     7,     8,     9,    -1,    11,    12,    -1,
      -1,    -1,    -1,    17,    18,    -1,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    39,    40,     0,     3,     6,     7,     8,     9,    11,
      12,    17,    18,    41,    42,    31,    33,     5,     3,     3,
       4,     5,    48,    54,    33,    33,    33,     3,    54,    41,
      54,    52,    54,    29,    30,    31,    31,    33,    29,    37,
      13,    14,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    53,    54,    53,     7,    33,    29,    32,    34,
      37,    54,     4,    54,    52,    54,    54,    54,    54,    54,
      54,    54,    54,    54,    54,    54,    54,    54,    34,    34,
       3,    46,    30,    29,    54,    29,    32,    32,    34,    35,
      35,    30,     3,    51,    54,    29,    43,    44,    54,    34,
      37,    29,    41,    41,    37,    35,     3,    36,    36,    53,
      47,    10,    49,    37,    41,    35,     7,    36,    50,     3,
      41,    30,    36,    54,    34,    35,    45,    41,    36
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

/* Line 1455 of yacc.c  */
#line 91 "parser.y"
    {
        /* Open all temp streams; they all land in CWD = temp/ */
        f_includes = fopen("mia_includes.tmp", "w");
        f_func     = fopen("mia_funcs.tmp",    "w");
        f_main     = fopen("mia_main.tmp",     "w");
        f_tac      = fopen("mia_tac.tac",      "w");
        current_out = f_main;
        TAC("; ===== Mia Three-Address Code =====\n");
        TAC("; Generated from source file\n");
        TAC("; Format: result = operand1 op operand2\n");
        TAC(";\n");
        TAC("BEGIN_MAIN\n");
    ;}
    break;

  case 3:

/* Line 1455 of yacc.c  */
#line 105 "parser.y"
    {
        TAC("END_MAIN\n");
        fclose(f_includes);
        fclose(f_func);
        fclose(f_main);
        fclose(f_tac);

        /* ── Stitch together generated_target.c ─────────────────────────── */
        FILE *final = fopen("generated_target.c", "w");
        fprintf(final, "/* Auto-Generated by Mia Transpiler */\n");
        fprintf(final, "#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\n#include <math.h>\n\n");

        char buf[512];
        f_includes = fopen("mia_includes.tmp", "r");
        while (fgets(buf, sizeof(buf), f_includes)) fprintf(final, "%s", buf);
        fclose(f_includes);

        /* runtime helpers */
        fprintf(final,
            "\nchar* __num_to_str(double d){\n"
            "    char* b=malloc(64); snprintf(b,64,\"%%g\",d); return b;\n"
            "}\n"
            "char* __concat(const char* s1,const char* s2){\n"
            "    char* b=malloc(strlen(s1)+strlen(s2)+1);\n"
            "    strcpy(b,s1); strcat(b,s2); return b;\n"
            "}\n\n");

        f_func = fopen("mia_funcs.tmp", "r");
        while (fgets(buf, sizeof(buf), f_func)) fprintf(final, "%s", buf);
        fclose(f_func);

        fprintf(final, "int main() {\n");
        f_main = fopen("mia_main.tmp", "r");
        while (fgets(buf, sizeof(buf), f_main)) fprintf(final, "%s", buf);
        fclose(f_main);
        fprintf(final, "    return 0;\n}\n");
        fclose(final);

        /* Remove temp stitching files (tac + symtable JSON kept for IDE) */
        remove("mia_includes.tmp");
        remove("mia_funcs.tmp");
        remove("mia_main.tmp");

        /* Dump symbol table JSON for the IDE panel */
        dump_symtable_json();
    ;}
    break;

  case 6:

/* Line 1455 of yacc.c  */
#line 158 "parser.y"
    {
        char *lib = strdup((yyvsp[(2) - (3)].str) + 1);          /* strip leading quote  */
        lib[strlen(lib) - 1] = '\0';         /* strip trailing quote */
        fprintf(f_includes, "#include \"%s\"\n", lib);
        TAC("; INCLUDE %s\n", lib);
        free(lib);
    ;}
    break;

  case 7:

/* Line 1455 of yacc.c  */
#line 166 "parser.y"
    {
        if (!is_declared((yyvsp[(2) - (5)].str))) {
            declare_var((yyvsp[(2) - (5)].str), (yyvsp[(4) - (5)].expr_info).type, yylineno);
            if ((yyvsp[(4) - (5)].expr_info).type == 1)
                fprintf(current_out, "    char* %s = %s;\n", (yyvsp[(2) - (5)].str), (yyvsp[(4) - (5)].expr_info).code);
            else
                fprintf(current_out, "    double %s = %s;\n", (yyvsp[(2) - (5)].str), (yyvsp[(4) - (5)].expr_info).code);
        } else {
            fprintf(current_out, "    %s = %s;\n", (yyvsp[(2) - (5)].str), (yyvsp[(4) - (5)].expr_info).code);
        }
        /* TAC: variable = tac_name_of_expr */
        TAC("%s = %s\n", (yyvsp[(2) - (5)].str), (yyvsp[(4) - (5)].expr_info).tac);
        free((yyvsp[(4) - (5)].expr_info).code); free((yyvsp[(4) - (5)].expr_info).tac);
    ;}
    break;

  case 8:

/* Line 1455 of yacc.c  */
#line 182 "parser.y"
    {
        fprintf(current_out, "    double %s[%s];\n", (yyvsp[(2) - (6)].str), (yyvsp[(4) - (6)].str));
        declare_var((yyvsp[(2) - (6)].str), 2, yylineno);
        TAC("%s = ARRAY[%s]\n", (yyvsp[(2) - (6)].str), (yyvsp[(4) - (6)].str));
    ;}
    break;

  case 9:

/* Line 1455 of yacc.c  */
#line 189 "parser.y"
    {
        fprintf(current_out, "    %s[(int)(%s)] = %s;\n", (yyvsp[(1) - (7)].str), (yyvsp[(3) - (7)].expr_info).code, (yyvsp[(6) - (7)].expr_info).code);
        TAC("%s[%s] = %s\n", (yyvsp[(1) - (7)].str), (yyvsp[(3) - (7)].expr_info).tac, (yyvsp[(6) - (7)].expr_info).tac);
        free((yyvsp[(3) - (7)].expr_info).code); free((yyvsp[(3) - (7)].expr_info).tac); free((yyvsp[(6) - (7)].expr_info).code); free((yyvsp[(6) - (7)].expr_info).tac);
    ;}
    break;

  case 10:

/* Line 1455 of yacc.c  */
#line 196 "parser.y"
    {
        fprintf(current_out, "    printf(\"\\n\");\n");
        /* bol_list already emitted TAC PRINT lines */
    ;}
    break;

  case 11:

/* Line 1455 of yacc.c  */
#line 203 "parser.y"
    {
            char *L_else = new_label();
            /* store label in a static so warna_opt can use it */
            /* simple approach: push/pop with a small stack */
            fprintf(current_out, "    if (%s) {\n", (yyvsp[(3) - (5)].expr_info).code);
            TAC("IF_FALSE %s GOTO %s\n", (yyvsp[(3) - (5)].expr_info).tac, L_else);
            /* We pass the label through a file-scope variable */
            /* (for simplicity we inline the label in a comment) */
            fprintf(f_tac, "; [else-label: %s]\n", L_else);
            free((yyvsp[(3) - (5)].expr_info).code); free((yyvsp[(3) - (5)].expr_info).tac); free(L_else);
        ;}
    break;

  case 13:

/* Line 1455 of yacc.c  */
#line 218 "parser.y"
    {
            char *L_start = new_label();
            char *L_end   = new_label();
            TAC("LABEL %s\n", L_start);
            TAC("IF_FALSE %s GOTO %s\n", (yyvsp[(3) - (5)].expr_info).tac, L_end);
            fprintf(current_out, "    while (%s) {\n", (yyvsp[(3) - (5)].expr_info).code);
            fprintf(f_tac, "; [end-label: %s]\n", L_end);
            free((yyvsp[(3) - (5)].expr_info).code); free((yyvsp[(3) - (5)].expr_info).tac); free(L_start); free(L_end);
        ;}
    break;

  case 14:

/* Line 1455 of yacc.c  */
#line 227 "parser.y"
    { fprintf(current_out, "    }\n"); TAC("GOTO [loop-start]\n"); TAC("LABEL [loop-end]\n"); ;}
    break;

  case 15:

/* Line 1455 of yacc.c  */
#line 231 "parser.y"
    {
            declare_var((yyvsp[(4) - (15)].str), 0, yylineno);
            fprintf(current_out, "    for(double %s = %s; %s; %s = %s) {\n",
                    (yyvsp[(4) - (15)].str), (yyvsp[(6) - (15)].expr_info).code, (yyvsp[(8) - (15)].expr_info).code, (yyvsp[(11) - (15)].str), (yyvsp[(13) - (15)].expr_info).code);
            TAC("%s = %s\n", (yyvsp[(4) - (15)].str), (yyvsp[(6) - (15)].expr_info).tac);
            char *L_start = new_label();
            char *L_end   = new_label();
            TAC("LABEL %s\n", L_start);
            TAC("IF_FALSE %s GOTO %s\n", (yyvsp[(8) - (15)].expr_info).tac, L_end);
            TAC("; [update: %s = %s, end-label: %s]\n", (yyvsp[(11) - (15)].str), (yyvsp[(13) - (15)].expr_info).tac, L_end);
            free((yyvsp[(6) - (15)].expr_info).code); free((yyvsp[(6) - (15)].expr_info).tac); free((yyvsp[(8) - (15)].expr_info).code); free((yyvsp[(8) - (15)].expr_info).tac);
            free((yyvsp[(13) - (15)].expr_info).code); free((yyvsp[(13) - (15)].expr_info).tac); free(L_start); free(L_end);
        ;}
    break;

  case 16:

/* Line 1455 of yacc.c  */
#line 244 "parser.y"
    { fprintf(current_out, "    }\n"); TAC("GOTO [for-start]\nLABEL [for-end]\n"); ;}
    break;

  case 17:

/* Line 1455 of yacc.c  */
#line 248 "parser.y"
    {
            current_out = f_func;
            fprintf(current_out, "double %s(", (yyvsp[(2) - (3)].str));
            TAC("\nBEGIN_FUNC %s\n", (yyvsp[(2) - (3)].str));
        ;}
    break;

  case 18:

/* Line 1455 of yacc.c  */
#line 254 "parser.y"
    { fprintf(current_out, ") {\n"); ;}
    break;

  case 19:

/* Line 1455 of yacc.c  */
#line 256 "parser.y"
    {
            fprintf(current_out, "}\n\n");
            TAC("END_FUNC %s\n\n", (yyvsp[(2) - (10)].str));
            current_out = f_main;
        ;}
    break;

  case 20:

/* Line 1455 of yacc.c  */
#line 263 "parser.y"
    {
        fprintf(current_out, "    return %s;\n", (yyvsp[(2) - (3)].expr_info).code);
        TAC("RETURN %s\n", (yyvsp[(2) - (3)].expr_info).tac);
        free((yyvsp[(2) - (3)].expr_info).code); free((yyvsp[(2) - (3)].expr_info).tac);
    ;}
    break;

  case 21:

/* Line 1455 of yacc.c  */
#line 270 "parser.y"
    {
        fprintf(current_out, "    %s(%s);\n", (yyvsp[(1) - (5)].str), (yyvsp[(3) - (5)].str));
        TAC("CALL %s\n", (yyvsp[(1) - (5)].str));
        free((yyvsp[(3) - (5)].str));
    ;}
    break;

  case 22:

/* Line 1455 of yacc.c  */
#line 279 "parser.y"
    {
        if ((yyvsp[(1) - (1)].expr_info).type == 1)
            fprintf(current_out, "    printf(\"%%s\", %s);\n", (yyvsp[(1) - (1)].expr_info).code);
        else
            fprintf(current_out, "    printf(\"%%g\", (double)(%s));\n", (yyvsp[(1) - (1)].expr_info).code);
        TAC("PRINT %s\n", (yyvsp[(1) - (1)].expr_info).tac);
        free((yyvsp[(1) - (1)].expr_info).code); free((yyvsp[(1) - (1)].expr_info).tac);
        (yyval.str) = strdup("");
    ;}
    break;

  case 23:

/* Line 1455 of yacc.c  */
#line 288 "parser.y"
    {
        if ((yyvsp[(3) - (3)].expr_info).type == 1)
            fprintf(current_out, "    printf(\"%%s\", %s);\n", (yyvsp[(3) - (3)].expr_info).code);
        else
            fprintf(current_out, "    printf(\"%%g\", (double)(%s));\n", (yyvsp[(3) - (3)].expr_info).code);
        TAC("PRINT %s\n", (yyvsp[(3) - (3)].expr_info).tac);
        free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
        (yyval.str) = strdup("");
    ;}
    break;

  case 24:

/* Line 1455 of yacc.c  */
#line 302 "parser.y"
    { fprintf(current_out, "    } else {\n"); TAC("ELSE\n"); ;}
    break;

  case 25:

/* Line 1455 of yacc.c  */
#line 304 "parser.y"
    { fprintf(current_out, "    }\n"); TAC("END_IF\n"); ;}
    break;

  case 26:

/* Line 1455 of yacc.c  */
#line 306 "parser.y"
    { fprintf(current_out, "    }\n"); TAC("END_IF\n"); ;}
    break;

  case 27:

/* Line 1455 of yacc.c  */
#line 311 "parser.y"
    {
        declare_var((yyvsp[(1) - (1)].str), 0, yylineno);
        fprintf(current_out, "double %s", (yyvsp[(1) - (1)].str));
        TAC("PARAM %s\n", (yyvsp[(1) - (1)].str));
        (yyval.str) = strdup("");
    ;}
    break;

  case 28:

/* Line 1455 of yacc.c  */
#line 317 "parser.y"
    {
        declare_var((yyvsp[(3) - (3)].str), 0, yylineno);
        fprintf(current_out, ", double %s", (yyvsp[(3) - (3)].str));
        TAC("PARAM %s\n", (yyvsp[(3) - (3)].str));
        (yyval.str) = strdup("");
    ;}
    break;

  case 29:

/* Line 1455 of yacc.c  */
#line 323 "parser.y"
    { (yyval.str) = strdup(""); ;}
    break;

  case 30:

/* Line 1455 of yacc.c  */
#line 328 "parser.y"
    {
        TAC("ARG %s\n", (yyvsp[(1) - (1)].expr_info).tac);
        (yyval.str) = (yyvsp[(1) - (1)].expr_info).code;
        free((yyvsp[(1) - (1)].expr_info).tac);
    ;}
    break;

  case 31:

/* Line 1455 of yacc.c  */
#line 333 "parser.y"
    {
        TAC("ARG %s\n", (yyvsp[(3) - (3)].expr_info).tac);
        char *buf = malloc(strlen((yyvsp[(1) - (3)].str)) + strlen((yyvsp[(3) - (3)].expr_info).code) + 3);
        sprintf(buf, "%s, %s", (yyvsp[(1) - (3)].str), (yyvsp[(3) - (3)].expr_info).code);
        free((yyvsp[(1) - (3)].str)); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
        (yyval.str) = buf;
    ;}
    break;

  case 32:

/* Line 1455 of yacc.c  */
#line 340 "parser.y"
    { (yyval.str) = strdup(""); ;}
    break;

  case 33:

/* Line 1455 of yacc.c  */
#line 344 "parser.y"
    { (yyval.expr_info) = (yyvsp[(1) - (1)].expr_info); ;}
    break;

  case 34:

/* Line 1455 of yacc.c  */
#line 348 "parser.y"
    {
        (yyval.expr_info).code = strdup((yyvsp[(1) - (1)].str));
        (yyval.expr_info).tac  = strdup((yyvsp[(1) - (1)].str));
        (yyval.expr_info).type = 0;
    ;}
    break;

  case 35:

/* Line 1455 of yacc.c  */
#line 353 "parser.y"
    {
        (yyval.expr_info).code = strdup((yyvsp[(1) - (1)].str));
        (yyval.expr_info).tac  = strdup((yyvsp[(1) - (1)].str));
        (yyval.expr_info).type = 1;
    ;}
    break;

  case 36:

/* Line 1455 of yacc.c  */
#line 358 "parser.y"
    {
        (yyval.expr_info).code = strdup((yyvsp[(1) - (1)].str));
        (yyval.expr_info).tac  = strdup((yyvsp[(1) - (1)].str));
        (yyval.expr_info).type = get_type((yyvsp[(1) - (1)].str));
    ;}
    break;

  case 37:

/* Line 1455 of yacc.c  */
#line 365 "parser.y"
    {
        (yyval.expr_info).type = 0;
        char *buf = malloc(strlen((yyvsp[(1) - (4)].str)) + strlen((yyvsp[(3) - (4)].expr_info).code) + 8);
        sprintf(buf, "%s[(int)(%s)]", (yyvsp[(1) - (4)].str), (yyvsp[(3) - (4)].expr_info).code);
        (yyval.expr_info).code = buf;
        char *tbuf = malloc(strlen((yyvsp[(1) - (4)].str)) + strlen((yyvsp[(3) - (4)].expr_info).tac) + 4);
        sprintf(tbuf, "%s[%s]", (yyvsp[(1) - (4)].str), (yyvsp[(3) - (4)].expr_info).tac);
        (yyval.expr_info).tac = tbuf;
        free((yyvsp[(3) - (4)].expr_info).code); free((yyvsp[(3) - (4)].expr_info).tac);
    ;}
    break;

  case 38:

/* Line 1455 of yacc.c  */
#line 377 "parser.y"
    {
        (yyval.expr_info).type = 0;
        char *c = malloc(strlen((yyvsp[(1) - (4)].str)) + strlen((yyvsp[(3) - (4)].str)) + 4);
        sprintf(c, "%s(%s)", (yyvsp[(1) - (4)].str), (yyvsp[(3) - (4)].str));
        (yyval.expr_info).code = c;
        char *tmp = new_tac_tmp();
        TAC("%s = CALL %s(%s)\n", tmp, (yyvsp[(1) - (4)].str), (yyvsp[(3) - (4)].str));
        (yyval.expr_info).tac = tmp;
        free((yyvsp[(3) - (4)].str));
    ;}
    break;

  case 39:

/* Line 1455 of yacc.c  */
#line 389 "parser.y"
    {
        if ((yyvsp[(1) - (3)].expr_info).type == 1 || (yyvsp[(3) - (3)].expr_info).type == 1) {
            (yyval.expr_info).type = 1;
            char *L = ((yyvsp[(1) - (3)].expr_info).type == 0) ? wrap_func("__num_to_str", (yyvsp[(1) - (3)].expr_info).code) : (yyvsp[(1) - (3)].expr_info).code;
            char *R = ((yyvsp[(3) - (3)].expr_info).type == 0) ? wrap_func("__num_to_str", (yyvsp[(3) - (3)].expr_info).code) : (yyvsp[(3) - (3)].expr_info).code;
            char *c = malloc(strlen(L) + strlen(R) + 16);
            sprintf(c, "__concat(%s, %s)", L, R);
            (yyval.expr_info).code = c;
        } else {
            (yyval.expr_info).type = 0;
            (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "+", (yyvsp[(3) - (3)].expr_info).code);
        }
        char *tmp = new_tac_tmp();
        TAC("%s = %s + %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp;
        free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 40:

/* Line 1455 of yacc.c  */
#line 406 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "-", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s - %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 41:

/* Line 1455 of yacc.c  */
#line 411 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "*", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s * %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 42:

/* Line 1455 of yacc.c  */
#line 416 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "/", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s / %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 43:

/* Line 1455 of yacc.c  */
#line 421 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "==", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s == %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 44:

/* Line 1455 of yacc.c  */
#line 426 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "!=", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s != %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 45:

/* Line 1455 of yacc.c  */
#line 431 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "<", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s < %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 46:

/* Line 1455 of yacc.c  */
#line 436 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, ">", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s > %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 47:

/* Line 1455 of yacc.c  */
#line 441 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "<=", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s <= %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 48:

/* Line 1455 of yacc.c  */
#line 446 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, ">=", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s >= %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 49:

/* Line 1455 of yacc.c  */
#line 451 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "&&", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s && %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;

  case 50:

/* Line 1455 of yacc.c  */
#line 456 "parser.y"
    {
        (yyval.expr_info).type = 0; (yyval.expr_info).code = make_expr((yyvsp[(1) - (3)].expr_info).code, "||", (yyvsp[(3) - (3)].expr_info).code);
        char *tmp = new_tac_tmp(); TAC("%s = %s || %s\n", tmp, (yyvsp[(1) - (3)].expr_info).tac, (yyvsp[(3) - (3)].expr_info).tac);
        (yyval.expr_info).tac = tmp; free((yyvsp[(1) - (3)].expr_info).code); free((yyvsp[(1) - (3)].expr_info).tac); free((yyvsp[(3) - (3)].expr_info).code); free((yyvsp[(3) - (3)].expr_info).tac);
    ;}
    break;



/* Line 1455 of yacc.c  */
#line 2109 "parser.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 1675 of yacc.c  */
#line 463 "parser.y"


void yyerror(const char *s) {
    fprintf(stderr, "Transpiler Error (line %d): %s\n", yylineno, s);
}

int main(int argc, char **argv) {
    extern FILE *yyin;
    if (argc > 1) {
        yyin = fopen(argv[1], "r");
        if (!yyin) { perror(argv[1]); return 1; }
    } else {
        fprintf(stderr, "Usage: mia.exe <file.mia>\n");
        return 1;
    }
    yyparse();
    return 0;
}

