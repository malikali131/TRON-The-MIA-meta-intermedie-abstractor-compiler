/* =============================================================================
 * symtable.h  —  Symbol Table for the Mia Transpiler
 * Location   : project/system/src/symtable.h
 *
 * Responsibilities:
 *   1. Track every declared variable (name + type).
 *   2. On program exit write mia_symtable.json to CWD (temp/) so the IDE
 *      can render the Symbol Table panel without any extra tooling.
 *
 * Type encoding:  0 = double (numeric)
 *                 1 = char*  (string)
 *                 2 = array  (double[])
 * ============================================================================= */

#ifndef SYMTABLE_H
#define SYMTABLE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_VARS 512

/* ── Internal storage ─────────────────────────────────────────────────────── */
typedef struct {
    char *name;
    int   type;        /* 0=double  1=string  2=array */
    int   line;        /* source line of first declaration */
} SymEntry;

static SymEntry sym_table[MAX_VARS];
static int      sym_count = 0;

/* ── type helpers ────────────────────────────────────────────────────────────*/
static inline const char *type_name(int t) {
    if (t == 1) return "string";
    if (t == 2) return "array";
    return "double";
}

/* ── Public API ──────────────────────────────────────────────────────────────*/

/* Returns the numeric type code for a declared variable, default 0 (double). */
static inline int get_type(const char *name) {
    for (int i = 0; i < sym_count; i++)
        if (strcmp(sym_table[i].name, name) == 0) return sym_table[i].type;
    return 0;
}

/* Returns true if the variable has been declared. */
static inline bool is_declared(const char *name) {
    for (int i = 0; i < sym_count; i++)
        if (strcmp(sym_table[i].name, name) == 0) return true;
    return false;
}

/* Declare a new variable or update the type of an existing one. */
static inline void declare_var(const char *name, int type, int line) {
    for (int i = 0; i < sym_count; i++) {
        if (strcmp(sym_table[i].name, name) == 0) {
            sym_table[i].type = type;   /* update type on re-assignment */
            return;
        }
    }
    if (sym_count < MAX_VARS) {
        sym_table[sym_count].name = strdup(name);
        sym_table[sym_count].type = type;
        sym_table[sym_count].line = line;
        sym_count++;
    }
}

/* ── JSON dump ───────────────────────────────────────────────────────────────
 * Writes mia_symtable.json in the current working directory (temp/).
 * Called once from parser.y's end-of-program action.
 * Format:
 *   [ {"name":"x","type":"double","line":4}, ... ]
 * ──────────────────────────────────────────────────────────────────────────*/
static inline void dump_symtable_json(void) {
    FILE *f = fopen("mia_symtable.json", "w");
    if (!f) return;
    fprintf(f, "[\n");
    for (int i = 0; i < sym_count; i++) {
        fprintf(f, "  {\"name\":\"%s\",\"type\":\"%s\",\"line\":%d}%s\n",
                sym_table[i].name,
                type_name(sym_table[i].type),
                sym_table[i].line,
                (i < sym_count - 1) ? "," : "");
    }
    fprintf(f, "]\n");
    fclose(f);
}

#endif /* SYMTABLE_H */